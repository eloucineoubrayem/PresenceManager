package com.example.presencemanager

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.app.AlertDialog
import android.text.util.Linkify
import android.text.method.LinkMovementMethod
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // هنا استعملنا btnCommernicer اللي كاين في الـ XML ديالك
        val btnCommencer = findViewById<Button>(R.id.btnCommernicer)

        btnCommencer.setOnClickListener {
            val intent = Intent(this, DashboardActivity::class.java)
            startActivity(intent)
        }

        // إضافة تفعيل النقر على نص الإصدار (TP3) لعرض معلومات المطور
        findViewById<TextView>(R.id.txtFooter).setOnClickListener {
            afficherInfosDeveloppeur()
        }
    }

    private fun afficherInfosDeveloppeur() {
        val dialogue = AlertDialog.Builder(this)
            .setTitle("Informations du développeur")
            .setMessage(
                "Application PrésenceManager\n" +
                        "Version: 1.0\n" +
                        "Développeur: OMAR BEN\n" +
                        "GitHub: https://github.com/VOTRE_IDENTIFIANT/PresenceManager"
            )
            .setPositiveButton("OK", null)
            .show()

        dialogue.findViewById<TextView>(android.R.id.message)?.let { texte ->
            Linkify.addLinks(texte, Linkify.WEB_URLS)
            texte.movementMethod = LinkMovementMethod.getInstance()
        }
    }
}