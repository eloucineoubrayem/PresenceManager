package com.example.presencemanager

import android.content.Intent
import android.os.Bundle
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import android.app.AlertDialog
import android.text.util.Linkify
import android.text.method.LinkMovementMethod
import androidx.appcompat.app.AppCompatActivity
import android.view.Menu
import android.view.MenuItem
import androidx.appcompat.view.ActionMode

class DashboardActivity : AppCompatActivity() {

    // 1. Declare CAB properties
    private var actionMode: ActionMode? = null

    private val cabCallback = object : ActionMode.Callback {
        override fun onCreateActionMode(mode: ActionMode, menu: Menu): Boolean {
            mode.menuInflater.inflate(R.menu.menu_cab_dashboard, menu)
            mode.title = "Actions contextuelles"
            return true
        }

        override fun onPrepareActionMode(mode: ActionMode, menu: Menu): Boolean = false

        override fun onActionItemClicked(mode: ActionMode, item: MenuItem): Boolean = when (item.itemId) {
            R.id.action_afficher -> {
                AlertDialog.Builder(this@DashboardActivity)
                    .setTitle("CAB")
                    .setMessage("Action Afficher exécutée.")
                    .setPositiveButton("OK", null)
                    .show()
                true
            }
            R.id.action_terminer -> {
                mode.finish()
                true
            }
            else -> false
        }

        override fun onDestroyActionMode(mode: ActionMode) {
            actionMode = null
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dashboard)

        setupCardListeners()
        setupProfileGesture()
        setupFooter()
    }

    private fun setupCardListeners() {
        val cardGroupes = findViewById<View>(R.id.cardGroupes)
        val cardAppel = findViewById<View>(R.id.cardAppel)
        val cardHistorique = findViewById<View>(R.id.cardHistorique)
        val cardStatistiques = findViewById<View>(R.id.cardStatistiques)

        // Click Listeners
        cardGroupes.setOnClickListener { startActivity(Intent(this, GroupesActivity::class.java)) }
        cardAppel.setOnClickListener { startActivity(Intent(this, AppelActivity::class.java)) }
        cardHistorique.setOnClickListener { startActivity(Intent(this, HistoriqueActivity::class.java)) }
        cardStatistiques.setOnClickListener { startActivity(Intent(this, StatistiquesActivity::class.java)) }

        // Long Click Listeners -> Example: Long clicking cardGroupes can also trigger CAB if desired, or keep Toasts
        cardGroupes.setOnLongClickListener {
            Toast.makeText(this, "Groupes: sélectionner ou consulter les groupes", Toast.LENGTH_SHORT).show()
            true
        }
        cardAppel.setOnLongClickListener {
            Toast.makeText(this, "Faire l'appel: démarrer une séance", Toast.LENGTH_SHORT).show()
            true
        }
        cardHistorique.setOnLongClickListener {
            Toast.makeText(this, "Historique: consulter les présences passées", Toast.LENGTH_SHORT).show()
            true
        }
        cardStatistiques.setOnLongClickListener {
            Toast.makeText(this, "Statistiques: voir les rapports", Toast.LENGTH_SHORT).show()
            true
        }
    }

    private fun setupProfileGesture() {
        val imgProfil = findViewById<ImageView>(R.id.imgProfil)
        val detecteur = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true

            // Double tap shows the "About" dialog
            override fun onDoubleTap(e: MotionEvent): Boolean {
                AlertDialog.Builder(this@DashboardActivity)
                    .setTitle("À propos de PrésenceManager")
                    .setMessage("Application de gestion des présences\nVersion 1.0")
                    .setPositiveButton("OK", null)
                    .show()
                return true
            }

            // Optional: You can trigger the CAB on a long press of the profile image
            override fun onLongPress(e: MotionEvent) {
                if (actionMode == null) {
                    actionMode = startSupportActionMode(cabCallback)
                }
            }
        })

        imgProfil.setOnTouchListener { _, evenement ->
            detecteur.onTouchEvent(evenement)
            true
        }
    }

    private fun setupFooter() {
        findViewById<TextView>(R.id.txtFooterDashboard).setOnClickListener {
            afficherInfosDeveloppeur()
        }
    }

    private fun afficherInfosDeveloppeur() {
        val dialogue = AlertDialog.Builder(this)
            .setTitle("Informations du développeur")
            .setMessage(
                "Application PrésenceManager\n" +
                        "Version: 1.0\n" +
                        "Développeur: el houcin dev\n" +
                        "GitHub: https://github.com/eloucineoubrayem/PresenceManager"
            )
            .setPositiveButton("OK", null)
            .show()

        dialogue.findViewById<TextView>(android.R.id.message)?.let { texte ->
            Linkify.addLinks(texte, Linkify.WEB_URLS)
            texte.movementMethod = LinkMovementMethod.getInstance()
        }
    }
}